import os
import secrets
from typing import Optional

import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

APP_NAME = "JARVIS Private Brain"
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen3:8b")
JARVIS_API_KEY = os.getenv("JARVIS_API_KEY", "")

SYSTEM_PROMPT = """You are J.A.R.V.I.S., a capable, calm, respectful personal AI assistant.
The owner is Saddam Hoque Chowdhury. Respond in the language the user uses:
Assamese, Hindi, or English. If the user mixes languages, you may naturally
mix them. Be honest about uncertainty and never claim to have operated a device,
sent a message, or completed an action unless a connected tool confirms it.
You are a self-hosted language model interface. Do not pretend to have tools
that have not been connected. Ask before consequential external actions.
"""

app = FastAPI(title=APP_NAME, version="0.2.0")


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)


def verify_key(authorization: Optional[str]):
    if not JARVIS_API_KEY:
        return
    expected = f"Bearer {JARVIS_API_KEY}"
    if not authorization or not secrets.compare_digest(authorization, expected):
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


@app.get("/health")
async def health():
    return {"status": "ok", "service": APP_NAME, "model": OLLAMA_MODEL}


@app.post("/chat")
async def chat(payload: ChatRequest, authorization: Optional[str] = Header(default=None)):
    verify_key(authorization)
    request_body = {
        "model": OLLAMA_MODEL,
        "stream": False,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": payload.message},
        ],
        "options": {"temperature": 0.65},
    }
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(120.0, connect=8.0)) as client:
            response = await client.post(f"{OLLAMA_BASE_URL}/api/chat", json=request_body)
            response.raise_for_status()
            data = response.json()
        reply = data.get("message", {}).get("content", "").strip()
        if not reply:
            raise HTTPException(status_code=502, detail="Local model returned an empty response")
        return {"reply": reply, "model": OLLAMA_MODEL}
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Cannot connect to Ollama. Start Ollama and pull the configured model.")
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"Ollama returned HTTP {exc.response.status_code}")
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Local model request timed out")
