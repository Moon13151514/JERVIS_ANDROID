# J.A.R.V.I.S. Private Brain (v0.2)

## Requirements
- Python 3.10+
- Ollama installed on the computer/server that will host the model
- A model downloaded in Ollama (default: `qwen3:8b`)
- Android device and host computer on the same trusted network, or an emulator

## Start the local model
Install Ollama, then:
```bash
ollama pull qwen3:8b
ollama serve
```

## Start the JARVIS API
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```
Set environment variables before starting. At minimum set `OLLAMA_MODEL`.
For LAN use, set a strong `JARVIS_API_KEY` and configure the Android app with the same key.
Run the server on the host LAN interface:
```bash
# macOS/Linux
export OLLAMA_BASE_URL=http://127.0.0.1:11434
export OLLAMA_MODEL=qwen3:8b
export JARVIS_API_KEY='your-long-random-secret'
uvicorn main:app --host 0.0.0.0 --port 8000
```
On Windows PowerShell use `$env:NAME="value"` for each variable.

Health check: `http://HOST-IP:8000/health`

## Android connection
- Android emulator: backend URL `http://10.0.2.2:8000`
- Physical Android phone: use the host computer's LAN IPv4 address, e.g. `http://192.168.1.20:8000`.
- Enter the URL and API key in JARVIS Settings.

The backend should only be exposed on a trusted private network. For remote access, use a properly secured VPN or HTTPS reverse proxy; do not expose the development server directly to the public internet.

## Language
The model is instructed to respond in the language used by the user. Android speech recognition and TextToSpeech depend on the device's installed speech services and language packs. Assamese support varies by Android speech provider; Hindi and English are more commonly available. The app currently asks Android's recognizer for Assamese (India) and uses a script-based TTS locale fallback. This is not a guarantee that every device has Assamese speech recognition or synthesis.
