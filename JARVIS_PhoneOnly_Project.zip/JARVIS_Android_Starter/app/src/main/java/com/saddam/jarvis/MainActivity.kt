package com.saddam.jarvis

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

private val Bg = Color(0xFF050B16)
private val Panel = Color(0xFF101D30)
private val Cyan = Color(0xFF55DDF5)
private val Muted = Color(0xFF9CB5C8)

private const val MODEL_URL =
    "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm"
private const val MODEL_FILE = "Qwen3-0.6B.litertlm"
private const val MODEL_BYTES = 613_722_264L
private const val MODEL_SHA256 = "c5f39b419192678c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108"

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private val worker = Executors.newSingleThreadExecutor()
    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            JarvisApp(
                modelFile = File(filesDir, MODEL_FILE),
                onDownload = { progress, done -> downloadModel(progress, done) },
                onLoad = { done -> loadModel(done) },
                onAsk = { prompt, done -> askLocalBrain(prompt, done) },
                onSpeak = { speak(it) },
                onLocalCommand = { handleLocalCommand(it) }
            )
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) selectVoiceFor("en")
    }

    private fun selectVoiceFor(text: String) {
        if (!ttsReady) return
        val locale = when {
            text.any { it in '\u0980'..'\u09FF' } -> Locale("as", "IN")
            text.any { it in '\u0900'..'\u097F' } -> Locale("hi", "IN")
            else -> Locale("en", "IN")
        }
        val result = tts?.setLanguage(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Keep the engine's current default voice rather than silently substituting
            // an unrelated language for Assamese text.
        }
    }

    private fun speak(text: String) {
        if (ttsReady) {
            selectVoiceFor(text)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        }
    }

    private fun downloadModel(onProgress: (Int) -> Unit, onDone: (String?) -> Unit) {
        worker.execute {
            val target = File(filesDir, MODEL_FILE)
            val temp = File(filesDir, "$MODEL_FILE.part")
            var connection: HttpURLConnection? = null
            try {
                if (target.exists() && target.length() == MODEL_BYTES && sha256(target) == MODEL_SHA256) {
                    runOnUiThread { onProgress(100); onDone(null) }
                    return@execute
                }
                temp.delete()
                connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20000
                    readTimeout = 60000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "JARVIS-Android/0.3")
                }
                connection.connect()
                val code = connection.responseCode
                if (code !in 200..299) error("Model download failed (HTTP $code).")
                val total = connection.contentLengthLong.takeIf { it > 0 } ?: MODEL_BYTES
                connection.inputStream.use { input ->
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(1024 * 1024)
                        var count: Long
                        var downloaded = 0L
                        var lastPercent = -1
                        while (input.read(buffer).also { count = it } != -1) {
                            output.write(buffer, 0, count)
                            downloaded += count
                            val percent = ((downloaded * 100) / total).toInt().coerceIn(0, 99)
                            if (percent != lastPercent) {
                                lastPercent = percent
                                runOnUiThread { onProgress(percent) }
                            }
                        }
                        output.fd.sync()
                    }
                }
                if (temp.length() != MODEL_BYTES) error("Downloaded file size does not match the published model.")
                if (sha256(temp) != MODEL_SHA256) error("Model checksum verification failed. Delete the partial download and retry.")
                if (target.exists()) target.delete()
                if (!temp.renameTo(target)) error("Could not move the verified model into app storage.")
                runOnUiThread { onProgress(100); onDone(null) }
            } catch (e: Exception) {
                temp.delete()
                runOnUiThread { onDone(e.message ?: "Unknown download error") }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun loadModel(onDone: (String?) -> Unit) {
        worker.execute {
            try {
                val file = File(filesDir, MODEL_FILE)
                require(file.exists() && file.length() == MODEL_BYTES) { "Download the model first." }
                if (engine == null) {
                    val candidate = Engine(
                        EngineConfig(
                            modelPath = file.absolutePath,
                            backend = Backend.CPU(),
                            cacheDir = cacheDir.absolutePath
                        )
                    )
                    candidate.initialize()
                    engine = candidate
                    conversation = candidate.createConversation(
                        ConversationConfig(
                            systemInstruction = Contents.of(
                                """You are J.A.R.V.I.S., a helpful personal AI assistant owned by Saddam Hoque Chowdhury.
Respond in the language the user uses: Assamese, Hindi, or English. Support mixed-language conversation naturally.
Be accurate, practical and concise. Be honest about what you can and cannot do.
You cannot directly operate apps unless the Android app provides a connected tool and reports success.
Never claim an action is complete unless the app confirms it. Ask for confirmation before consequential actions."""
                            )
                        )
                    )
                }
                runOnUiThread { onDone(null) }
            } catch (e: Exception) {
                runOnUiThread { onDone(e.message ?: "Could not load on-device model.") }
            }
        }
    }

    private fun askLocalBrain(prompt: String, onDone: (String) -> Unit) {
        worker.execute {
            try {
                val reply = conversation?.sendMessage(prompt)?.text
                    ?: "The local AI model is not loaded yet. Download and load it first."
                runOnUiThread { onDone(reply) }
            } catch (e: Exception) {
                runOnUiThread { onDone("Local AI error: ${e.message ?: "unknown error"}") }
            }
        }
    }

    private fun handleLocalCommand(raw: String): String? {
        val q = raw.trim().lowercase(Locale.getDefault())
        return when {
            q.contains("open settings") || q == "settings" -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); "Opening Android settings."
            }
            q.contains("open camera") || q == "camera" -> {
                startActivity(Intent("android.media.action.IMAGE_CAPTURE")); "Opening the camera."
            }
            q.contains("open youtube") -> launchPackage("com.google.android.youtube", "YouTube")
            q.contains("open whatsapp") -> launchPackage("com.whatsapp", "WhatsApp")
            q.contains("open chrome") -> launchPackage("com.android.chrome", "Chrome")
            q.contains("what time") || q == "time" ->
                "The time is ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}."
            q.startsWith("search for ") -> {
                val term = raw.substringAfter("search for ", raw)
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(term))))
                "Searching the web for $term."
            }
            else -> null
        }
    }

    private fun launchPackage(packageName: String, label: String): String {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        return if (launch != null) "Opening $label." else "$label is not installed or unavailable."
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        worker.execute {
            try { conversation?.close() } catch (_: Exception) {}
            try { engine?.close() } catch (_: Exception) {}
        }
        worker.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisApp(
    modelFile: File,
    onDownload: ((Int) -> Unit, (String?) -> Unit) -> Unit,
    onLoad: ((String?) -> Unit) -> Unit,
    onAsk: (String, (String) -> Unit) -> Unit,
    onSpeak: (String) -> Unit,
    onLocalCommand: (String) -> String?
) {
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("PHONE-ONLY AI • OFFLINE READY") }
    var transcript by remember { mutableStateOf("Welcome, Commander. Download the local AI brain to begin. Once installed, conversations can run without an internet connection.") }
    var progress by remember { mutableIntStateOf(0) }
    var downloading by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var modelReady by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }

    fun runCommand(command: String) {
        if (command.isBlank() || busy) return
        val local = onLocalCommand(command)
        if (local != null) {
            transcript = local
            status = "LOCAL DEVICE ACTION"
            onSpeak(local)
        } else if (!modelReady) {
            transcript = "Please download and load the on-device AI model first."
            status = "AI MODEL NOT LOADED"
        } else {
            busy = true
            status = "THINKING ON THIS PHONE"
            transcript = "Processing locally…"
            onAsk(command) { reply ->
                transcript = reply
                busy = false
                status = "ON-DEVICE AI READY"
                onSpeak(reply)
            }
        }
        input = ""
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF07182A), Bg, Color(0xFF02050B))))) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                contentPadding = PaddingValues(top = 26.dp, bottom = 28.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("J.A.R.V.I.S.", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("ON-DEVICE PERSONAL INTELLIGENCE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                        IconButton(onClick = { showInfo = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "About device AI", tint = Muted)
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                }
                item {
                    Box(Modifier.size(206.dp).background(Brush.radialGradient(listOf(Color(0xFF174B68), Color(0xFF0B1B2D), Bg)), CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(158.dp).background(Color(0xFF0E2639), CircleShape), contentAlignment = Alignment.Center) {
                            Text("J", color = Cyan, fontSize = 88.sp, fontWeight = FontWeight.ExtraLight)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(status, color = Cyan, fontSize = 10.sp, letterSpacing = 2.5.sp)
                    Spacer(Modifier.height(22.dp))
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = .94f)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text("J.A.R.V.I.S. RESPONSE", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(transcript, color = Color.White, fontSize = 15.sp, lineHeight = 22.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1928)), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Download, tint = Cyan, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("LOCAL AI BRAIN", color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("Qwen3 0.6B • 614 MB • on-device", color = Muted, fontSize = 11.sp)
                                }
                                Text(if (modelReady) "READY" else if (modelFile.exists()) "DOWNLOADED" else "NOT INSTALLED",
                                    color = if (modelReady) Color(0xFF70E6A0) else Cyan, fontSize = 10.sp)
                            }
                            if (downloading) {
                                Spacer(Modifier.height(12.dp))
                                LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Cyan)
                                Text("$progress% downloaded", color = Muted, fontSize = 11.sp)
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        downloading = true
                                        status = "DOWNLOADING MODEL TO PHONE"
                                        onDownload({ p -> progress = p }) { error ->
                                            downloading = false
                                            if (error == null) {
                                                transcript = "Model downloaded and checksum verified. Tap Load AI Brain."
                                                status = "MODEL INSTALLED"
                                            } else {
                                                transcript = "Download error: $error"
                                                status = "DOWNLOAD FAILED"
                                            }
                                        }
                                    },
                                    enabled = !downloading && !loading && !modelReady,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E7898))
                                ) { Text(if (downloading) "DOWNLOADING…" else "DOWNLOAD AI") }
                                OutlinedButton(
                                    onClick = {
                                        loading = true
                                        status = "LOADING MODEL INTO MEMORY"
                                        onLoad { error ->
                                            loading = false
                                            if (error == null) {
                                                modelReady = true
                                                status = "PRIVATE AI ONLINE"
                                                transcript = "J.A.R.V.I.S. local brain is active. You can now chat offline."
                                            } else {
                                                status = "MODEL LOAD FAILED"
                                                transcript = error
                                            }
                                        }
                                    },
                                    enabled = !loading && !downloading && !modelReady && modelFile.exists(),
                                    modifier = Modifier.weight(1f),
                                    border = BorderStroke(1.dp, Cyan),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                                ) { Text(if (loading) "LOADING…" else "LOAD BRAIN") }
                            }
                            Text("First download needs internet and about 1 GB free space is recommended. After download, AI chat runs locally.",
                                color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                }
                item {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Talk to your private AI…", color = Muted) },
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Muted, focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        trailingIcon = {
                            IconButton(onClick = { runCommand(input) }, enabled = !busy) {
                                Icon(Icons.Default.Send, contentDescription = "Send", tint = Cyan)
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in Assamese, Hindi or English")
                            }
                            try { voiceLauncher.launch(intent) } catch (_: Exception) { status = "VOICE RECOGNITION UNAVAILABLE" }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0E7898)),
                        shape = RoundedCornerShape(15.dp)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null)
                        Spacer(Modifier.width(9.dp))
                        Text("TAP TO SPEAK", letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { runCommand(input) }, enabled = input.isNotBlank() && !busy,
                        modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF18364D))) {
                        Text(if (busy) "THINKING…" else "SEND COMMAND")
                    }
                    Spacer(Modifier.height(18.dp))
                }
                item {
                    Text("QUICK DEVICE COMMANDS", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("Open WhatsApp", "Open YouTube", "Open Settings", "What time is it?", "Explain how black holes form")
                            .forEach { cmd ->
                                OutlinedButton(onClick = { runCommand(cmd) }, modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    border = BorderStroke(1.dp, Color(0xFF24465D)), shape = RoundedCornerShape(11.dp)
                                ) { Text(cmd) }
                            }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("PRIVATE • LOCAL • NO CLOUD AI REQUIRED", color = Color(0xFF547086), fontSize = 10.sp, letterSpacing = 1.3.sp)
                }
            }
            if (showInfo) {
                AlertDialog(
                    onDismissRequest = { showInfo = false },
                    title = { Text("Phone-only J.A.R.V.I.S.") },
                    text = {
                        Text("The language model is downloaded to this phone and runs locally using Google's LiteRT-LM. Internet is needed for the initial model download and Android speech recognition may use your device's speech service. Assamese voice output depends on whether your installed TTS engine provides an Assamese voice.")
                    },
                    confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Close") } }
                )
            }
        }
    }
}
