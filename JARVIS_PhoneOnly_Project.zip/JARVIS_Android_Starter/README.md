# J.A.R.V.I.S. Android — v0.3.0 Phone-only Local AI

This version removes the computer-hosted backend. The LLM is downloaded to the Android phone and executed on-device with Google's LiteRT-LM Kotlin API.

## What's included
- Android Studio source project (Kotlin + Jetpack Compose).
- Local Qwen3-0.6B LiteRT-LM model download from Hugging Face.
- Download progress, exact byte-size check and SHA-256 verification.
- On-device CPU inference; no remote AI server or API key.
- Persistent conversation object while the app process is alive.
- Android speech recognition intent and local Android TextToSpeech.
- Existing starter commands for launching selected apps, settings, camera, time and web search.

## First-time setup
1. Open the project in Android Studio and sync Gradle.
2. Build and install the APK on the Android phone.
3. Connect to Wi-Fi and ensure at least 1 GB of free storage (more is better).
4. Open J.A.R.V.I.S. and tap **DOWNLOAD AI**. The model file is about 614 MB.
5. Wait for checksum verification, then tap **LOAD BRAIN**.
6. Chat. Text generation runs locally on the phone.

## Model
- Model: `litert-community/Qwen3-0.6B`
- File: `Qwen3-0.6B.litertlm`
- Published size: 613,722,264 bytes
- SHA-256: `c5f39b419192678c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108`
- License: Apache-2.0 (see model card)
- Model card: https://huggingface.co/litert-community/Qwen3-0.6B
- Runtime: LiteRT-LM Android Kotlin API 0.18.0
- Default backend: CPU for broad compatibility. GPU/NPU acceleration needs device-specific validation.

## Voice notes
Speech input uses Android's speech-recognition service. It may require network access depending on the speech provider and installed language packs. Text-to-speech uses the phone's installed TTS voices. English and Hindi are commonly available; Assamese availability varies by TTS engine/device. Install additional voice data from Android Text-to-Speech settings where available.

## Important limitations
This is an early phone-only build, not a finished always-on JARVIS. It does not yet have an animated photorealistic humanoid, offline speech-to-text, guaranteed Assamese TTS, background wake-word listening, long-term encrypted memory, broad app automation or self-updating code. The 0.6B model is a lightweight starter and is not comparable to a large cloud model in reasoning quality.

Android Studio is still needed somewhere to compile a distributable APK. This ZIP contains source code, not an APK. If you have only the phone, a mobile-compatible build service or an Android IDE workflow is needed to compile it on-device; the model itself runs on the phone after installation.


## Build APK using only your phone (cloud build)
If you do not own a computer, you can use GitHub Actions from the GitHub mobile app or phone browser:
1. Create a GitHub repository and upload the contents of this project ZIP.
2. Keep the default branch named `main`.
3. Open the repository's **Actions** tab and run **Build JARVIS Android APK** (or push to `main`).
4. When the workflow finishes, open its run and download the `jarvis-debug-apk` artifact.
5. Extract the artifact on your phone and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

This uses GitHub's cloud machines to compile the APK; no personal computer is needed. A GitHub account and internet access are required.
