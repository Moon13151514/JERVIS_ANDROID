# v0.3 phone-only architecture

Android Compose UI
  -> local command router (explicit Android intents)
  -> LiteRT-LM Kotlin API
  -> Qwen3-0.6B `.litertlm` model stored in app-private files
  -> response text
  -> Android TextToSpeech

No cloud LLM endpoint, local server, PC or API key is used. Initial model download requires internet. The inference engine runs on-device after download.

Model source and checksum are pinned in MainActivity.kt. The app checks the expected file length and SHA-256 before loading.
